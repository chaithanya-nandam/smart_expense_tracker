"use client";

import { useState, useEffect } from "react";

import Sidebar from "../components/Sidebar";

export default function SettingsPage() {

  const [monthlyBudget, setMonthlyBudget] =
    useState("5000");

  const [defaultCategory, setDefaultCategory] =
    useState("Food");

  useEffect(() => {

    const savedBudget =
      localStorage.getItem("monthlyBudget");

    const savedCategory =
      localStorage.getItem("defaultCategory");

    if (savedBudget) {
      setMonthlyBudget(savedBudget);
    }

    if (savedCategory) {
      setDefaultCategory(savedCategory);
    }

  }, []);

  const saveSettings = () => {

    localStorage.setItem(
      "monthlyBudget",
      monthlyBudget
    );

    localStorage.setItem(
      "defaultCategory",
      defaultCategory
    );

    alert("Settings saved successfully!");

  };

  return (
    <main className="flex bg-[#0F172A] min-h-screen">

      <Sidebar />

      <section className="flex-1 px-8 py-7">

        <div className="mb-10">

          <h1 className="text-4xl font-bold text-white">
            Settings
          </h1>

          <p className="text-gray-400 mt-2">
            Manage your finance preferences and application settings.
          </p>

        </div>

        <div className="max-w-3xl space-y-6">

          <div className="bg-[#111827] border border-gray-800 rounded-3xl p-6 hover:border-blue-500/40 hover:shadow-lg hover:shadow-blue-500/10 transition duration-300">

            <h2 className="text-white text-xl font-semibold mb-6">
              Finance Preferences
            </h2>

            <div className="space-y-5">

              <div>

                <label className="block text-gray-400 text-sm mb-3">
                  Monthly Budget
                </label>

                <input
                  type="number"
                  value={monthlyBudget}
                  onChange={(e) =>
                    setMonthlyBudget(
                      e.target.value
                    )
                  }
                  className="w-full bg-[#1E293B] text-white p-4 rounded-2xl outline-none"
                />

              </div>

              <div>

                <label className="block text-gray-400 text-sm mb-3">
                  Default Expense Category
                </label>

                <select
                  value={defaultCategory}
                  onChange={(e) =>
                    setDefaultCategory(
                      e.target.value
                    )
                  }
                  className="w-full bg-[#1E293B] text-white p-4 rounded-2xl outline-none"
                >

                  <option value="Food">
                    Food
                  </option>

                  <option value="Travel">
                    Travel
                  </option>

                  <option value="Shopping">
                    Shopping
                  </option>

                  <option value="Bills">
                    Bills
                  </option>

                  <option value="Entertainment">
                    Entertainment
                  </option>

                  <option value="Health">
                    Health
                  </option>

                  <option value="Education">
                    Education
                  </option>

                  <option value="Other">
                    Other
                  </option>

                </select>

              </div>

              <button
                onClick={saveSettings}
                className="bg-blue-600 hover:bg-blue-700 hover:scale-[1.02] transition duration-300 px-6 py-3 rounded-2xl text-white font-medium"
              >
                Save Settings
              </button>

            </div>

          </div>

          <div className="bg-[#111827] border border-gray-800 rounded-3xl p-6 hover:border-blue-500/40 hover:shadow-lg hover:shadow-blue-500/10 transition duration-300">

            <h2 className="text-white text-xl font-semibold mb-6">
              Application Information
            </h2>

            <div className="space-y-4">

              <div className="flex items-center justify-between">

                <p className="text-gray-400">
                  Application
                </p>

                <p className="text-white">
                  Smart Expense Analytics
                </p>

              </div>

              <div className="flex items-center justify-between">

                <p className="text-gray-400">
                  Version
                </p>

                <p className="text-white">
                  v1.0.0
                </p>

              </div>

              <div className="flex items-center justify-between">

                <p className="text-gray-400">
                  Developed By
                </p>

                <p className="text-white">
                  Chaithanya
                </p>

              </div>

              <div className="flex items-center justify-between">

                <p className="text-gray-400">
                  Storage
                </p>

                <p className="text-green-400">
                  Local Storage Active
                </p>

              </div>

            </div>

          </div>

        </div>

      </section>

    </main>
  );
}